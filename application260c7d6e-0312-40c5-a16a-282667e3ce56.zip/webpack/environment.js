module.exports = {
  I18N_HASH: 'generated_hash',
  SERVER_API_URL: '',
  __VERSION__: process.env.hasOwnProperty('APP_VERSION') ? process.env.APP_VERSION : 'DEV',
  __DEBUG_INFO_ENABLED__: false,
  __PUBLIC_KEY__:
    '-----BEGIN PUBLIC KEY-----MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtHlNm6J2TUNGVvitwcO3N29RCGRs58d2T3l+gyqsWUiKP9ojoZpRU76toSWgtqup9suDe0d3bzz/Dr4dJmwe8mr2PY4RKGJ2I8okRHjk37LQfTlKR32lbw48OQBfQ62FNwtkoS8G7HOU4tB+FRn1bvYCUZM2M3OWvhd/8YjOLswosuARZeTNT81uYxqBrcsmCrbaYBosoiamx9lpcjtpjJlnP0LZ90Ywvi5a0Akjpj7eHTFxDiFDhNogasgk/nxTYlA3r6tPx91ScCxCktWow+sv6kY5hmFNtx19mQmpq3DVGpV+Bo4/t+q87cPMwKmKONNJxWAvaPGOH+2rqngAHQIDAQAB-----END PUBLIC KEY-----',
};
