# Cecabank WebApp

This application was generated using Speed Code Cecabank, intended to be the entrypoint for web app development under Cecabank environment

## Project Structure

Node is required for generation and recommended for development. `package.json` is always generated for a better development experience with prettier, commit hooks, scripts and so on.

In the project root, Speed Code Cecabank generates configuration files for tools like git, prettier, eslint, husky, and others that are well known and you can find references in the web.

## Generator's dependency installation to write JDL entities

In order to generate your code according to JDL file design, you must install a `generator-jhipster-speedcode-ckb` dependency.
It will be permormed following two steps:

- Command `npm install`, which will add to the node modules the generator package.
- CLI command configuration:

  1. Go to the microservice directory you are using (where you want to write you JDL). You can use command `pwd` to locate it.
  2. Open you `zsh` configuration file with `nano ~/.zshrc` or `vim ~/.zshrc`, either valid.
  3. Add the generator's CLI route environment variable:

  ```
  export SPEEDCODE_CLI="/route/to/your/proyect/node_modules/generator-jhipster-speedcode-ckb-jdl/cli/cli.cjs"
  ```

  4. Create an alias to ensure CLI's invocation:

  ```
  alias speedcode-ckb="node $SPEEDCODE_CLI
  ```

  5. Reload `zsh` file for changes to take effect: `source ~/.zshrc`

## Development

Start your application in the development profile by running the command:

```
./mvnw
```

## Authentication process and security

One of the biggest points of this application is the **authentication and authorization component (CAA)**, which is in charge of performing OIDC login with Azure AD, and generating the subsequent tokens for services consumption.

When the Angular front client is launched, the entry point is the login button, which will lead to Azure SSO website (the one previously configured by the final user). Then, if the login is successful, a **JWT token** will be returned by Azure, including all the user's information and data reflected in Azure: name, email, application roles, etc; and some other fields related to the configurated application in Azure, or the identifier of the process.

After login is performed, **two JWT tokens** are generated, extracting the received user information from Azure:

- **Front token**: this one is **returned to the Angular front client**, in order to be stored in session, and later used as auth element in service requests
- **Micro token**: this one is generated strictly after the front token, as a twin, and is **stored in cache**, from where it will be extracted after a service request (with front token included) is received and approved, in order to send it as auth element to the corresponding microservice.

Both tokens are signed using **asymmetrical cryptography**, specifically the algorithm RS256 (key size 2048, exponent 65537), where a **pair of keys** (private and public) is involved, ONE PAIR FOR EACH TOKEN (2 pairs in total):

- For the front token, the private key is used at the **CAA component** for signing, and the public is employed at the **signature filter** which intercepts each http request at the BFF
- For the micro token, the private key (different to the front token one) is employed as well at the **CAA component**, whereas the public key (different to the front token one) should be located at the destination **microservice**, in order to be employed by the signature filter which intercepts the requests (as in the BFF)

In the following diagram it is shown how these two tokens work, including the purpose for the micro token in the relationship BFF - microservice.
![alt text](./img.png)

## Considerations to keep in mind

1. **Signing keys**: This refers to the inclusion of a pair of keys at the file `application.properties`, which is one of the ways that Spring Boot allows for configuration to be externalized and can be used to define the necessary parameters for the application to work correctly. At present, a couple of example keys (public/private) have been defined. It is important to review and replace these keys with the final ones before deploying the application in a production environment.
2. **Azure SSO** connection parameters. In order to provide your particular configuration for **Azure SSO**, you have to include an `application.properties` file with your own parameters (CLIENTID_AZURE, TENANTID_AZURE, KID_JWK, N_JWK, REDIRECT_URI) to the `src/main/resources` folder. Otherwise, execution will fail, as these environment variables have not been defined.
3. **Integration with microservices**. When the connection to a Speed Code-generated microservices environment is implemented, remember that the micro token should be **extracted from cache** (using the _nonce_ from the received front token as the search key), in order to include it as authorization header in the http request. Otherwise, the microservice's signature filter will take down the request. Remember to provide the corresponding public key to each working micro.
4. **Token expiration**. By default, front and micro tokens inherit the expiration from the token received from Azure, that is, 1h. However, this is not mandatory, and it should be adapted to the developer's project requirements. Remember that the value is set at the method `createRS256Token()`, at the class `TokenProviderConfig.java`.

## Others

### Using Docker to simplify development (optional)

You can use Docker to improve your JHipster development experience. A number of docker-compose configuration are available in the [src/main/docker](src/main/docker) folder to launch required third party services.

You can also fully dockerize your application and all the services that it depends on.
To achieve this, first build a docker image of your app by running:

```
npm run java:docker
```

Or build a arm64 docker image when using an arm64 processor os like MacOS with M1 processor family running:

```
npm run java:docker:arm64
```

Then run:

```
docker compose -f src/main/docker/app.yml up -d
```
