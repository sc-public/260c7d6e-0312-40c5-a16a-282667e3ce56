export interface AzureUrl {
  url_login: string;
}

export interface JwtToken {
  id_token: string;
}

export interface AzureResponse {
  id_token: string;
  state: string;
  session_state: string;
}
