import { Component, OnDestroy, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

import { Subject, takeUntil } from 'rxjs';

import { AccountService } from 'app/core/auth/account.service';
import { Title } from '@angular/platform-browser';
import { AzureResponse, AzureUrl } from './caa.model';
import { LoginService } from './login.service';
import { CaaService } from './caa.service';

@Component({
  selector: 'jhi-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})
export class LoginComponent implements OnInit, OnDestroy {
  private destroy$ = new Subject<void>();

  constructor(
    private titleService: Title,
    public accountService: AccountService, // TODO: Parece que no funciona. Se usa para consultar el estado de la autenticación
    private activatedRoute: ActivatedRoute,
    private loginService: LoginService,
    private router: Router,
    private caaService: CaaService,
  ) {}

  ngOnInit(): void {
    this.titleService.setTitle('Cecabank - Login');
    if (this.accountService.isAuthenticated()) {
      // Autenticados, nos vamos al home
      this.router.navigateByUrl('');
    } else {
      // No estamos autenticados, comprobamos si podemos hacerlo con parámetros de la url
      this.checkURL();
    }
  }

  /**
   * Comprueba si tenemos parametros en la url para loguearnos
   */
  checkURL(): void {
    this.activatedRoute.fragment.pipe(takeUntil(this.destroy$)).subscribe(fragment => {
      if (fragment) {
        this.login(new URLSearchParams(fragment));
      }
      console.log(this.activatedRoute);
    });
  }

  /**
   * Intenta el login a partir de los parametros de la url
   * @param params Los parámetros en url que nos devuelve Azure AD (id_token, state, session_state)
   */
  login(params: URLSearchParams): void {
    const azureResponse: AzureResponse = {
      id_token: params.get('id_token') ?? '',
      state: params.get('state') ?? '',
      session_state: params.get('session_state') ?? '',
    };

    this.loginService
      .login(azureResponse)
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next: () => {
          this.router.navigateByUrl(''); // nos vamos al home
        },
        error(error) {
          console.error('Error en la autenticación: ', error);
        },
      });
  }

  /**
   * Consulta en el servicio de configuración la url de Azure AD para autenticarnos y nos redirige a dicha url
   */
  goToAzureAD(): void {
    this.caaService
      .getLoginAzureADUrl()
      .pipe(takeUntil(this.destroy$))
      .subscribe({
        next(azureUrl: AzureUrl) {
          window.location.href = azureUrl.url_login;
        },
      });
  }

  /**
   * Método ngOnDestroy
   *
   * Este método es parte del ciclo de vida de un componente Angular y se ejecuta justo antes de que el componente sea destruido.
   * En este caso, se utiliza para desuscribirnos de todos los observables y evitar posibles fugas de memoria.
   *
   * Buenas Prácticas:
   * - Para evitar fugas de memoria, siempre tenemos que desuscribirnos de los observables y cancelar suscripciones en ngOnDestroy.
   * - Utilizamos un Subject llamado 'destroy$' que actúa como una señal para que las suscripciones se desuscriban cuando el componente es destruido.
   * - Llamamos a 'next()' en 'destroy$' para indicar que el componente está siendo destruido, lo que desencadenará la desuscripción en las suscripciones relevantes.
   * - Llamamos a 'complete()' en 'destroy$' para liberar todos los recursos asociados al Subject después de que se complete su desuscripción.
   *
   * Para que este método sea efectivo, tenemos que declarar en nuestros módulos la variable destroy$ y usarla dentro de todos nuestros observables
   *
   * ```typescript
   * private destroy$ = new Subject<void>();
   *
   * test(): void {
   *   this.observabletest.pipe(takeUntil(this.destroy$)).subscribe(()) => {
   *      // do stuff
   *   });
   * }
   *
   * ngOnDestroy(): void {
   *   this.destroy$.next();
   *   this.destroy$.complete();
   * }
   * ```
   */
  ngOnDestroy(): void {
    this.destroy$.next();
    this.destroy$.complete();
  }
  public setDocTitle(newTitle: string): void {
    this.titleService.setTitle(newTitle);
  }
}
