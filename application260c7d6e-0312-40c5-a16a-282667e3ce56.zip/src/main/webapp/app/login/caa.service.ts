import { Injectable } from '@angular/core';
import { ApplicationConfigService } from 'app/core/config/application-config.service';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

import { AzureResponse, AzureUrl, JwtToken } from './caa.model';

@Injectable({
  providedIn: 'root',
})
export class CaaService {
  httpOptions!: any;

  constructor(
    private applicationConfigService: ApplicationConfigService,
    private http: HttpClient,
  ) {}

  getLoginAzureADUrl(): Observable<AzureUrl> {
    console.error(this.applicationConfigService.getEndpointFor('ceca/properties/public'));
    //return this.http.get<AzureUrl>(this.applicationConfigService.getEndpointFor('ceca/properties/public'));
    return this.http.get<AzureUrl>('http://localhost:8080/ceca/properties/public');
  }

  getJwtToken(params: AzureResponse): Observable<JwtToken> {
    return this.http.get<JwtToken>(this.applicationConfigService.getEndpointFor('auth/oidc'), {
      params: {
        id_token: params.id_token,
        state: params.state,
        session_state: params.session_state,
      },
    });
  }
}
