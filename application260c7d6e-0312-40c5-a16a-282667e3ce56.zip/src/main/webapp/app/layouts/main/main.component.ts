import { Component } from '@angular/core';

@Component({
  selector: 'jhi-main',
  templateUrl: './main.component.html',
})
export class MainComponent {}
