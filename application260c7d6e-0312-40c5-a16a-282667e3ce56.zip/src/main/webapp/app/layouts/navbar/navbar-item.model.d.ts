type NavbarItem = {
  name: string;
  route: string;
};

export default NavbarItem;
