declare const __DEBUG_INFO_ENABLED__: boolean;
declare const __VERSION__: string;
declare const __PUBLIC_KEY__: string;

export const VERSION = __VERSION__;
export const DEBUG_INFO_ENABLED = __DEBUG_INFO_ENABLED__;
export const PUBLIC_KEY = __PUBLIC_KEY__;
