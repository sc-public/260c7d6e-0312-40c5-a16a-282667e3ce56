import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { Authority } from 'app/config/authority.constants';
import { UserRouteAccessService } from 'app/core/auth/user-route-access.service';
import { errorRoute } from './layouts/error/error.route';
import { PrivateViewsComponent } from './layouts/private-views/private-views.component';

@NgModule({
  imports: [
    RouterModule.forRoot(
      [
        {
          path: 'login',
          loadChildren: () => import('./login/login.module').then(m => m.LoginModule),
        },
        {
          path: '',
          component: PrivateViewsComponent,
          canActivate: [UserRouteAccessService],
          data: {
            authorities: [Authority.USER],
          },
          children: [
            /*{
              path: 'entities',
              loadChildren: () => import(`./entities/entity-routing.module`).then(m => m.EntityRoutingModule),
            },*/
            {
              path: 'home',
              loadChildren: () => import('./home/home.module').then(m => m.HomeModule),
            },
          ],
        },
        ...errorRoute,
      ],
      { onSameUrlNavigation: 'reload' },
    ),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
