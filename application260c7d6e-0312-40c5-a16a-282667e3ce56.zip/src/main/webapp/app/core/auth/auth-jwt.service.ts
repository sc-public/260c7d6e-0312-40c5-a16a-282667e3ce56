import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { AzureResponse } from 'app/login/caa.model';

import { PUBLIC_KEY } from 'app/app.constants';

// In case of not recognizing the library, write command npm i @types/jsrsasign
import { KJUR } from 'jsrsasign';
import { ApplicationConfigService } from '../config/application-config.service';
import { StateStorageService } from './state-storage.service';

type JwtToken = {
  id_token: string;
};

@Injectable({ providedIn: 'root' })
export class AuthServerProvider {
  constructor(
    private http: HttpClient,
    private stateStorageService: StateStorageService,
    private applicationConfigService: ApplicationConfigService,
  ) {}

  getToken(): string {
    return this.stateStorageService.getAuthenticationToken() ?? '';
  }

  login(params: AzureResponse): Observable<void> {
    return this.http
      .get<JwtToken>(this.applicationConfigService.getEndpointFor('auth/oidc'), {
        params: {
          id_token: params.id_token,
          state: params.state,
          session_state: params.session_state,
        },
      })
      .pipe(
        map(response => {
          this.authenticateSuccess(response, true);
        }),
      );
  }

  logout(): Observable<void> {
    return new Observable(observer => {
      this.stateStorageService.clearAuthenticationToken();
      observer.complete();
    });
  }
  setJwtToken(jwt: JwtToken, rememberMe: boolean): void {
    this.stateStorageService.storeAuthenticationToken(jwt.id_token, rememberMe);
  }

  private authenticateSuccess(response: JwtToken, rememberMe: boolean): void {
    // Ahora el método verificará la firma usando la clave pública del entorno
    if (this.verifyTokenSignature(response.id_token)) {
      console.log('JWT token signature is valid.');
      this.stateStorageService.storeAuthenticationToken(response.id_token, rememberMe);
    } else {
      console.error('JWT token signature is invalid.');
      // Manejar aquí el caso de una firma inválida
    }
  }

  private verifyTokenSignature(token: string): boolean {
    try {
      const isValid = KJUR.jws.JWS.verify(token, PUBLIC_KEY);
      return isValid;
    } catch (error) {
      console.error('Error verifying token signature:', error);
      return false;
    }
  }
}
