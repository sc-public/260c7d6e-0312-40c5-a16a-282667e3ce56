import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { AzureResponse } from 'app/login/caa.model';
import { AuthServerProvider } from './auth-jwt.service';

@Injectable({
  providedIn: 'root',
})
export class AuthenticationService {
  private authenticationCache$: Observable<boolean> | null = null;
  private authenticated = false;

  constructor(private authServerProvider: AuthServerProvider) {}

  checkAuthentication(force?: boolean): Observable<boolean> {
    if (!this.authenticationCache$ || force) {
      this.authenticationCache$ = this.verifyToken().pipe(
        catchError(() => of(false)),
        tap(authenticated => this.setAuthenticated(authenticated)),
      );
    }
    return this.authenticationCache$;
  }

  authenticate(credentials: AzureResponse): Observable<void> {
    return this.authServerProvider.login(credentials).pipe(tap(() => this.setAuthenticated(true)));
  }

  isAuthenticated(): boolean {
    return this.authenticated;
  }

  logout(): void {
    this.authServerProvider.logout().subscribe({
      complete: () => {
        console.error();
        this.setAuthenticated(false);
        this.authenticationCache$ = of(false);
      },
    });
  }

  private verifyToken(): Observable<boolean> {
    const hasToken = !!localStorage.getItem('jhi-authenticationToken');
    return of(hasToken);
  }

  private setAuthenticated(authenticated: boolean): void {
    this.authenticated = authenticated;
  }
}
