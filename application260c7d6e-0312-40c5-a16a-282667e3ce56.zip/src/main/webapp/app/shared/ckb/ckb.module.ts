import { NgModule } from '@angular/core';

import { CecabankModule } from '@ckb/cecabank-components';

@NgModule({
  imports: [CecabankModule],
  exports: [CecabankModule],
})
export class CkbModule {}
