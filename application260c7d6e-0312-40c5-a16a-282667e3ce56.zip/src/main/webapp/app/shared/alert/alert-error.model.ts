export class AlertError {
  constructor(public message: string) {}
}
