package es.cecabank.app.handler.exception;

import es.cecabank.app.domain.enums.LevelEnum;
import es.cecabank.app.dto.RestErrorDTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UnauthorizedControlException extends RuntimeException {

    private RestErrorDTO error;

    public UnauthorizedControlException(String msg) {
        super(msg);
        this.error = new RestErrorDTO(401, msg, LevelEnum.ERROR, msg);
    }
}
