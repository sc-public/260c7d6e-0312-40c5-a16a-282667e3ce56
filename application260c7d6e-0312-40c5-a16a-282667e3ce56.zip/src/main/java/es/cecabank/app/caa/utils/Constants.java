package es.cecabank.app.caa.utils;

/**
 * Application constants.
 */
public final class Constants {

    public static String STATE_JWT_CACHE = "state_jwt_cache";
    public static final String TOKEN_SCOPE = "scope";
    public static final String JWT_TYP = "JWT";
    public static final String AUTHORITIES_KEY = "auth";
}
