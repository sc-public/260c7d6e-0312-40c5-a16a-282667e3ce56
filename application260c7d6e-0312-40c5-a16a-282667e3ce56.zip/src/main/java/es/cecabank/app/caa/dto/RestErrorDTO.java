//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package es.cecabank.app.caa.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import es.cecabank.app.caa.domain.model.LevelEnum;
import org.springframework.http.HttpStatus;

@JsonIgnoreProperties(ignoreUnknown = true)
public class RestErrorDTO {

    private String code;
    private LevelEnum level;
    private String message;
    private String description;

    public RestErrorDTO(HttpStatus httpCode, LevelEnum level, String moreInformation) {
        this.code = Integer.toString(httpCode.value());
        this.message = httpCode.getReasonPhrase();
        this.level = level;
        this.description = moreInformation;
    }

    public RestErrorDTO(HttpStatus httpCode, String message, LevelEnum level, String moreInformation) {
        this.code = Integer.toString(httpCode.value());
        this.message = message;
        this.level = level;
        this.description = moreInformation;
    }

    public RestErrorDTO(int httpCode, String message, LevelEnum level, String moreInformation) {
        this.code = Integer.toString(httpCode);
        this.message = message;
        this.level = level;
        this.description = moreInformation;
    }

    public String getCode() {
        return this.code;
    }

    public LevelEnum getLevel() {
        return this.level;
    }

    public String getMessage() {
        return this.message;
    }

    public String getDescription() {
        return this.description;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public void setLevel(LevelEnum level) {
        this.level = level;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public RestErrorDTO() {}

    @Override
    public String toString() {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(this);
        } catch (JsonProcessingException e) {
            return super.toString();
        }
    }
}
