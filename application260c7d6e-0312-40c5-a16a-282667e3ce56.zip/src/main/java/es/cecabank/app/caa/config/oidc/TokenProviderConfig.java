package es.cecabank.app.caa.config.oidc;

import com.auth0.jwt.interfaces.DecodedJWT;
import es.cecabank.app.caa.utils.Constants;
import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.Jwts.SIG;
import java.io.IOException;
import java.io.StringReader;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;
import java.util.stream.Collectors;
import lombok.Getter;
import lombok.Setter;
import org.bouncycastle.util.io.pem.PemReader;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@ConfigurationProperties(prefix = "ceca.signature")
@Configuration
@Setter
@Getter
public class TokenProviderConfig {

    public String createRS256Token(DecodedJWT b2cToken, String privateKey, String type) {
        final JwtBuilder jwt = Jwts
            .builder()
            .header()
            .add("typ", Constants.JWT_TYP)
            .keyId(b2cToken.getKeyId())
            .and()
            .claim("roles", b2cToken.getClaim("roles").asList(String.class))
            .claim("exp", b2cToken.getExpiresAt())
            .claim("iss", b2cToken.getIssuer())
            .claim("aud", b2cToken.getAudience().stream().collect(Collectors.joining(","))) // Usa 'claim' en lugar de 'setAudience'
            .claim("nbf", b2cToken.getNotBefore())
            .claim("acr", b2cToken.getClaim("acr").asString())
            .claim("nonce", b2cToken.getClaim("nonce").asString())
            .claim("name", b2cToken.getClaim("name").asString());

        if (type.equals("front")) {
            jwt.claim("oid", b2cToken.getClaim("oid").asString());
            jwt.claim("subz", b2cToken.getSubject());
            jwt.claim("emails", b2cToken.getClaim("preferred_username").asString());
        } else if (type.equals("micro")) {
            jwt.claim("sub", b2cToken.getSubject());
            jwt.claim("subz", b2cToken.getClaim("subz").asString());
            jwt.claim("emails", b2cToken.getClaim("emails").asString());
        }

        return jwt.signWith(privateKeyRSA(privateKey), SIG.RS256).compact();
    }

    /**
     * This method converts a PEM-encoded private key string into an RSAPrivateKey object.
     *
     * @param privatePEMKey The PEM-encoded private key string.
     * @return The RSAPrivateKey object.
     * @throws RuntimeException if there's an issue reading the PEM object or generating the private key.
     */
    private RSAPrivateKey privateKeyRSA(String privatePEMKey) {
        String parsedPrivatePEMKey = privatePEMKey
            .replace("-----BEGIN PRIVATE KEY-----", "")
            .replace("-----END PRIVATE KEY-----", "")
            .replaceAll("\\s", "");
        try (StringReader stringReader = new StringReader(parsedPrivatePEMKey); PemReader pemReader = new PemReader(stringReader)) {
            //byte[] content = pemReader.readPemObject().getContent();
            byte[] decoded = Base64.getDecoder().decode(parsedPrivatePEMKey);

            return (RSAPrivateKey) KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(decoded));
        } catch (IOException | NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new RuntimeException("Error generating RSAPrivateKey from PEM", e);
        } catch (Exception e) {
            throw new RuntimeException("Unknown exception from PEM", e);
        }
    }
}
