package es.cecabank.app.caa.service.impl;

import com.auth0.jwt.interfaces.DecodedJWT;
import es.cecabank.app.caa.config.FrontProperties;
import es.cecabank.app.caa.config.oidc.OidcB2CProperties;
import es.cecabank.app.caa.config.oidc.TokenProviderConfig;
import es.cecabank.app.caa.domain.model.JWTToken;
import es.cecabank.app.caa.domain.model.URLAzureAD;
import es.cecabank.app.caa.handler.exception.UnauthorizedControlException;
import es.cecabank.app.caa.service.CecaResourceService;
import es.cecabank.app.caa.utils.AuthUtils;
import es.cecabank.app.caa.utils.Constants;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

@Service
public class CecaResourceServiceImpl implements CecaResourceService {

    private final Logger log = LoggerFactory.getLogger(CecaResourceService.class);

    private final CacheManager cacheManager;

    @Autowired
    private FrontProperties fps;

    @Autowired
    private OidcB2CProperties oidcB2CProperties;

    @Autowired
    private TokenProviderConfig tokenProviderConfig;

    @Value("${ceca.signature.base64-private-ES256-front}")
    private String privateKeyFront;

    @Value("${ceca.signature.base64-private-ES256-micro}")
    private String privateKeyMicro;

    public CecaResourceServiceImpl(CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }

    @Override
    public URLAzureAD generateURL() {
        String uuidState = UUID.randomUUID().toString();
        String uuidNonce = UUID.randomUUID().toString();

        Cache authCache = cacheManager.getCache(Constants.STATE_JWT_CACHE);
        if (authCache != null) {
            authCache.put(uuidState, uuidNonce);
        }

        return new URLAzureAD(fps, uuidState, uuidNonce);
    }

    /**
     * This method is in charge of generating the front token, which will be returned to the front client,
     * and the micro token, stored in cache for later use with the microservices
     *
     * @param cecabankToken
     * @param state
     * @param sessionState
     * @return
     */
    @Override
    public JWTToken generateTokens(String cecabankToken, String state, String sessionState) {
        String errorMessage = "";
        if (sessionState == null) {
            errorMessage = "Session State is null, is not possible to continue with the process";
            log.error(errorMessage);
            throw new UnauthorizedControlException(errorMessage);
        }
        if (cecabankToken == null) {
            errorMessage = "Token is null, is not possible to continue with the process";
            log.error(errorMessage);
            throw new UnauthorizedControlException(errorMessage);
        }
        if (state == null) {
            errorMessage = "State is null, is not possible to continue with the process";
            log.error(errorMessage);
            throw new UnauthorizedControlException(errorMessage);
        }

        log.info(String.format("AzureAD Token: {%s}", cecabankToken));

        final DecodedJWT decodedCecabankToken = AuthUtils.getDecodedJWT(cecabankToken);

        Cache authCache = cacheManager.getCache(Constants.STATE_JWT_CACHE);
        String uuidNonce = authCache != null ? authCache.get(state, String.class) : null;
        AuthUtils.validateApplication(oidcB2CProperties, decodedCecabankToken, uuidNonce);

        AuthUtils.validateExpiration(oidcB2CProperties, decodedCecabankToken);

        // This token is meant to be the one for the front - BFF communication, so it's returned to the front client
        // at the end of the method
        String frontToken = tokenProviderConfig.createRS256Token(decodedCecabankToken, privateKeyFront, "front");

        // This token is stored in cache because it's meant to be the one for the BFF - microservices communication,
        // and will be later recovered when an endpoint call is performed by the front client with the front token
        String microToken = tokenProviderConfig.createRS256Token(AuthUtils.getDecodedJWT(frontToken), privateKeyMicro, "micro");
        authCache.put(uuidNonce, microToken);

        // Temporarily disabled due to technical issues with Spring Security
        /*Authentication authentication = new BearerTokenAuthenticationToken(frontToken);
        SecurityContextHolder.getContext().setAuthentication(authentication);*/

        return new JWTToken(frontToken);
    }
}
