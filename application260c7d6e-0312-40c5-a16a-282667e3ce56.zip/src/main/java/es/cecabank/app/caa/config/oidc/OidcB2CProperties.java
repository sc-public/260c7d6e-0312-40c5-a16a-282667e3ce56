package es.cecabank.app.caa.config.oidc;

import java.util.Arrays;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@ConfigurationProperties(prefix = "ceca.azure.active-directory.b2c", ignoreUnknownFields = true)
@Configuration
public class OidcB2CProperties {

    private String[] allowedFlows;
    private String nonce;
    private String audience;
    private String issuer;
    private String discoveryUrl;
    private String roleAssignmentUrl;
    private String roleAssignmentResourceId;
    private Integer delay_iat;
    private Integer limit_iat;

    public String[] getAllowedFlows() {
        return allowedFlows;
    }

    public void setAllowedFlows(String[] allowedFlows) {
        this.allowedFlows = allowedFlows;
    }

    public String getNonce() {
        return nonce;
    }

    public void setNonce(String nonce) {
        this.nonce = nonce;
    }

    public String getAudience() {
        return audience;
    }

    public void setAudience(String audience) {
        this.audience = audience;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public String getDiscoveryUrl() {
        return discoveryUrl;
    }

    public void setDiscoveryUrl(String discoveryUrl) {
        this.discoveryUrl = discoveryUrl;
    }

    public String getRoleAssignmentUrl() {
        return roleAssignmentUrl;
    }

    public void setRoleAssignmentUrl(String roleAssignmentUrl) {
        this.roleAssignmentUrl = roleAssignmentUrl;
    }

    public String getRoleAssignmentResourceId() {
        return roleAssignmentResourceId;
    }

    public void setRoleAssignmentResourceId(String roleAssignmentResourceId) {
        this.roleAssignmentResourceId = roleAssignmentResourceId;
    }

    public Integer getDelay_iat() {
        return delay_iat;
    }

    public void setDelay_iat(Integer delay_iat) {
        this.delay_iat = delay_iat;
    }

    public Integer getLimit_iat() {
        return limit_iat;
    }

    public void setLimit_iat(Integer limit_iat) {
        this.limit_iat = limit_iat;
    }

    @Override
    public String toString() {
        return (
            "OidcB2CProperties{" +
            "allowedFlows=" +
            Arrays.toString(allowedFlows) +
            ", nonce='" +
            nonce +
            '\'' +
            ", audience='" +
            audience +
            '\'' +
            ", issuer='" +
            issuer +
            '\'' +
            ", discoveryUrl='" +
            discoveryUrl +
            '\'' +
            ", roleAssignmentUrl='" +
            roleAssignmentUrl +
            '\'' +
            ", roleAssignmentResourceId='" +
            roleAssignmentResourceId +
            '\'' +
            ", delay_iat=" +
            delay_iat +
            ", limit_iat=" +
            limit_iat +
            '}'
        );
    }
}
