package es.cecabank.app.caa.web.rest;

import com.fasterxml.jackson.core.JsonProcessingException;
import es.cecabank.app.caa.domain.model.JWTToken;
import es.cecabank.app.caa.domain.model.URLAzureAD;
import es.cecabank.app.caa.service.CecaResourceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Validated
@CrossOrigin(origins = "http://localhost:9001")
public class CecaResource {

    @Autowired
    CecaResourceService ccs;

    /**
     * CAA endpoint returning Azure SSO URL for SSO login
     *
     */
    @GetMapping("/ceca/properties/public")
    public ResponseEntity<URLAzureAD> frontPublicProperties() {
        return ResponseEntity.ok(this.ccs.generateURL());
    }

    /**
     * CAA endpoint for frontend login with Azure credentials
     *
     * @param token
     * @param state
     * @param sessionState
     * @throws JsonProcessingException
     */
    @GetMapping("/auth/oidc")
    public ResponseEntity<JWTToken> authorizeOidcIdToken(
        @RequestParam("id_token") final String token,
        @RequestParam("state") final String state,
        @RequestParam("session_state") final String sessionState
    ) throws JsonProcessingException {
        return ResponseEntity.ok(ccs.generateTokens(token, state, sessionState));
    }
}
