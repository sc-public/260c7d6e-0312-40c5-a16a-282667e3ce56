package es.cecabank.app.caa.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigInteger;

public class TokenDTO {

    @JsonProperty("grant_type")
    private String grantType;

    @JsonProperty("access_token")
    private String accessToken;

    @JsonProperty("expires_in")
    private BigInteger expiresIn;

    @JsonProperty("expires_at")
    private BigInteger expiresAt;

    private String scope;

    public String getGrantType() {
        return grantType;
    }

    public void setGrantType(String grantType) {
        this.grantType = grantType;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public BigInteger getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(BigInteger expiresIn) {
        this.expiresIn = expiresIn;
    }

    public BigInteger getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(BigInteger expiresAt) {
        this.expiresAt = expiresAt;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

    @Override
    public String toString() {
        return (
            "TokenDTO{" +
            "grantType='" +
            grantType +
            '\'' +
            ", accessToken='" +
            accessToken +
            '\'' +
            ", expiresIn=" +
            expiresIn +
            ", expiresAt=" +
            expiresAt +
            ", scope='" +
            scope +
            '\'' +
            '}'
        );
    }
}
