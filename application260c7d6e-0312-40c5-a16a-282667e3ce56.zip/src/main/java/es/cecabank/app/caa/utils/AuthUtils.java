package es.cecabank.app.caa.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.interfaces.DecodedJWT;
import es.cecabank.app.caa.config.oidc.OidcB2CProperties;
import es.cecabank.app.caa.handler.exception.UnauthorizedControlException;
import java.util.Calendar;
import java.util.Date;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;

@Slf4j
public class AuthUtils {

    public static DecodedJWT getDecodedJWT(String token) {
        DecodedJWT decodedJWT = null;
        //log.debug(String.format("Token received: %s", token));
        try {
            decodedJWT = JWT.decode(token);
        } catch (JWTDecodeException e) {
            //log.error("Error occurred during token decoding. Maybe token is not valid. ", e);
        }
        return decodedJWT;
    }

    public static void validateExpiration(OidcB2CProperties oidcB2CProperties, DecodedJWT decodedJWT) {
        //log.debug("JWT expiresAt: " + decodedJWT.getExpiresAt().getTime());
        //log.debug("System time: " + Calendar.getInstance().getTime().getTime());
        //log.debug("Is valid expires: " + decodedJWT.getExpiresAt().before(Calendar.getInstance().getTime()));

        Long tokenExpiration = decodedJWT.getExpiresAt().getTime();
        Long currentTimestamp = Calendar.getInstance().getTime().getTime();

        if (null != oidcB2CProperties.getDelay_iat() && decodedJWT.getIssuedAt() != null) {
            Date delay_iat = DateUtils.addSeconds(Calendar.getInstance().getTime(), oidcB2CProperties.getDelay_iat());
            //log.info("System time delay: {}", delay_iat.getTime());
            if (!decodedJWT.getIssuedAt().after(delay_iat)) {
                throw new UnauthorizedControlException("Token is in the future!");
            }
        }

        if (oidcB2CProperties.getLimit_iat() != null && decodedJWT.getIssuedAt() != null) {
            Date limit_iat = DateUtils.addSeconds(Calendar.getInstance().getTime(), -oidcB2CProperties.getLimit_iat());
            //log.info("System time limit: {}", limit_iat.getTime());
            if (!decodedJWT.getIssuedAt().before(limit_iat)) {
                throw new UnauthorizedControlException("Token is not new!");
            }
        }

        if (tokenExpiration < currentTimestamp) {
            throw new UnauthorizedControlException("Token is expired!");
        }
    }

    public static void validateApplication(OidcB2CProperties oidcB2CProperties, final DecodedJWT decodedJWT, final String nonce) {
        if (!decodedJWT.getClaim("nonce").asString().equals(nonce)) {
            throw new UnauthorizedControlException("Nonce is not correct");
        }

        boolean correctAudience = false;
        for (String audience : decodedJWT.getAudience()) {
            if (audience.equalsIgnoreCase(oidcB2CProperties.getAudience())) {
                correctAudience = true;
                break;
            }
        }

        if (!correctAudience) {
            throw new UnauthorizedControlException("Audience is not correct");
        }

        if (!decodedJWT.getIssuer().equals(oidcB2CProperties.getIssuer())) {
            throw new UnauthorizedControlException("Issuer is not correct");
        }
    }
}
