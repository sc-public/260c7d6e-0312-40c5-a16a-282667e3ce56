package es.cecabank.app.caa.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import es.cecabank.app.caa.config.FrontProperties;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class URLAzureAD {

    @JsonProperty("url_login")
    private String urlLogin;

    public URLAzureAD(FrontProperties fps, String uuidState, String uuidNonce) {
        this.urlLogin = fps.getB2cLoginFormUrl().replaceAll("(\\$\\{state\\})", uuidState).replaceAll("(\\$\\{nonce\\})", uuidNonce);
    }
}
