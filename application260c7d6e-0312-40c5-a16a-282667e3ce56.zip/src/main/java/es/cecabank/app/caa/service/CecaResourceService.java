package es.cecabank.app.caa.service;

import es.cecabank.app.caa.domain.model.JWTToken;
import es.cecabank.app.caa.domain.model.URLAzureAD;

public interface CecaResourceService {
    URLAzureAD generateURL();

    JWTToken generateTokens(String cecabankToken, String state, String sessionState);
}
