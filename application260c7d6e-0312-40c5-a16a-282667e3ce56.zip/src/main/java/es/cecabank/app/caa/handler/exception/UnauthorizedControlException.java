package es.cecabank.app.caa.handler.exception;

import es.cecabank.app.caa.domain.model.LevelEnum;
import es.cecabank.app.caa.dto.RestErrorDTO;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UnauthorizedControlException extends RuntimeException {

    private RestErrorDTO error;

    public UnauthorizedControlException(String msg) {
        super(msg);
        this.error = new RestErrorDTO(401, msg, LevelEnum.ERROR, msg);
    }
}
