package es.cecabank.app.caa.domain.model;

import com.fasterxml.jackson.annotation.JsonCreator;

public enum LevelEnum {
    INFO,
    WARNING,
    ERROR,
    FATAL;

    private LevelEnum() {}

    @JsonCreator
    public static LevelEnum fromString(String value) {
        if (
            value.equalsIgnoreCase("INFO") ||
            value.equalsIgnoreCase("WARNING") ||
            value.equalsIgnoreCase("ERROR") ||
            value.equalsIgnoreCase("FATAL")
        ) {
            LevelEnum[] var1 = values();
            int var2 = var1.length;

            for (int var3 = 0; var3 < var2; ++var3) {
                LevelEnum type = var1[var3];
                if (type.name().equalsIgnoreCase(value)) {
                    return type;
                }
            }
        }

        return null;
    }
}
