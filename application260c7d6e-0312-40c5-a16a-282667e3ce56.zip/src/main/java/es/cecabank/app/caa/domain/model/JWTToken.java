package es.cecabank.app.caa.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class JWTToken {

    @JsonProperty("id_token")
    private String idToken;

    public JWTToken(String idToken) {
        this.idToken = idToken;
    }
}
