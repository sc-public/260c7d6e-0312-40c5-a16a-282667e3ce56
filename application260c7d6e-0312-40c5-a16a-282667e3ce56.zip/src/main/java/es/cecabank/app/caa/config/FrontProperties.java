package es.cecabank.app.caa.config;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@ConfigurationProperties(prefix = "ceca.frontend", ignoreUnknownFields = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@Configuration
@Getter
@Setter
public class FrontProperties {

    public String getB2cLoginFormUrl() {
        return b2cLoginFormUrl;
    }

    public void setB2cLoginFormUrl(String b2cLoginFormUrl) {
        this.b2cLoginFormUrl = b2cLoginFormUrl;
    }

    public String getB2cRegistryFormUrl() {
        return b2cRegistryFormUrl;
    }

    public void setB2cRegistryFormUrl(String b2cRegistryFormUrl) {
        this.b2cRegistryFormUrl = b2cRegistryFormUrl;
    }

    public String getScfPluginUrl() {
        return scfPluginUrl;
    }

    public void setScfPluginUrl(String scfPluginUrl) {
        this.scfPluginUrl = scfPluginUrl;
    }

    private String b2cLoginFormUrl;
    private String b2cRegistryFormUrl;
    private String scfPluginUrl;
}
