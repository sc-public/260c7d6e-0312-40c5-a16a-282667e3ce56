/**
 * Application configuration.
 */
package es.cecabank.app.config;
