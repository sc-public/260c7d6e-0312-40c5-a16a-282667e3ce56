/**
 * Application security utilities.
 */
package es.cecabank.app.security;
