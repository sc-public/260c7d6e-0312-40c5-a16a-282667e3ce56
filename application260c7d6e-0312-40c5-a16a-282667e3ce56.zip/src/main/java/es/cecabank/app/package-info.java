/**
 * Application root.
 */
package es.cecabank.app;
