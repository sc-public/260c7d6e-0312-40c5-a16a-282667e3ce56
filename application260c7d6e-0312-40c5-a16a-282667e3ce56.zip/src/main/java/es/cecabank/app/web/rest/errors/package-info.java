/**
 * Rest layer error handling.
 */
package es.cecabank.app.web.rest.errors;
