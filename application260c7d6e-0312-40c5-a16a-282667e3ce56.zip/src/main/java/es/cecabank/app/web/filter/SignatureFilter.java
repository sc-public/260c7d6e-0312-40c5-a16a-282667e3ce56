package es.cecabank.app.web.filter;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTCreationException;
import com.auth0.jwt.exceptions.JWTDecodeException;
import com.auth0.jwt.exceptions.SignatureVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import es.cecabank.app.caa.config.oidc.OidcB2CProperties;
import es.cecabank.app.caa.utils.AuthUtils;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.StringReader;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import org.bouncycastle.util.io.pem.PemReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.OncePerRequestFilter;

/**
 * Custom filter that is applied to each HTTP request.
 * It inherits from the OncePerRequestFilter class to ensure that the filter is applied once per request.
 *
 * The main purpose of this class is to validate the signature of authorization tokens that come in HTTP requests.
 * It uses a public key to verify whether the token has been signed with the corresponding private key using the asymmetric ES256 algorithm.
 * In addition, it also checks the expiration of the token.
 */
public class SignatureFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(SignatureFilter.class);

    private final String publicKey;

    private OidcB2CProperties oidcB2CProperties;

    public SignatureFilter(String publicKey) {
        this.oidcB2CProperties = new OidcB2CProperties();
        this.publicKey = publicKey;
    }

    /**
     * This method is a filter which receives a request for any endpoint, extracts the authorization token from it, and checks with the defined
     * public key whether it has been signed by the twin private key or not, with the asymmetrical algorithm ES256. The expiration of the token is
     * also checked
     *
     * @param request
     * @param response
     * @param filterChain
     * @throws ServletException
     * @throws IOException
     **/
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
        throws ServletException, IOException {
        String errorMsg = "";

        // Check if the request is a service call
        if (request.getRequestURI().startsWith("/api")) {
            String authToken = request.getHeader("Authorization").substring(7);

            try {
                // Throws JWTDecodeException when the token is not a valid JWT
                DecodedJWT decodedJWT = JWT.decode(authToken);

                // Throws SignatureVerificationException, IllegalArgumentException, JWTCreationException
                checkSignature(decodedJWT);

                AuthUtils.validateExpiration(oidcB2CProperties, decodedJWT);

                log.info("================================================================");
                log.info("SIGNATURE OK");
                log.info("================================================================");
            } catch (SignatureVerificationException e) {
                errorMsg = "ERROR: Token signature not valid";
                log.error(errorMsg, e);
                response.sendError(HttpServletResponse.SC_UNAUTHORIZED, errorMsg);
            } catch (IllegalArgumentException e) {
                errorMsg = "ERROR: Token verification: Illegal argument exception";
                log.error(errorMsg, e);
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, errorMsg);
            } catch (JWTCreationException e) {
                errorMsg = "ERROR: Token verification: Create JWT exception";
                log.error(errorMsg, e);
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, errorMsg);
            } catch (JWTDecodeException e) {
                errorMsg = "ERROR: JWT AuthToken decode exception";
                log.error(errorMsg, e);
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, errorMsg);
            } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
                errorMsg = "ERROR: Create ECPublickey exception";
                log.error(errorMsg, e);
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, errorMsg);
            }
        }

        filterChain.doFilter(request, response);
    }

    /**
     * Receives a decoded JWT token and verifies its signature using the defined public key and the ES256 algorithm.
     * If the signature is valid, it returns true. If the signature is not valid, it throws a SignatureVerificationException.
     * If any error occurs during verification, it throws an IllegalArgumentException, JWTCreationException or ParseException.
     *
     * @param decodedJWT The decoded JWT token to be verified.
     * @return true if the signature is valid.
     * @throws SignatureVerificationException if the signature is invalid.
     * @throws IllegalArgumentException if the provided public or private key is null or if it is not of the correct type.
     * @throws JWTCreationException if there is a problem creating the JWT token.
     */
    private boolean checkSignature(final DecodedJWT decodedJWT)
        throws SignatureVerificationException, IllegalArgumentException, JWTCreationException, NoSuchAlgorithmException, InvalidKeySpecException, IOException {
        RSAPublicKey rsaPublicKey = publicKeyRSA(publicKey);

        // Throws IllegalArgumentException o JWTCreationException
        final Algorithm algorithm = Algorithm.RSA256(rsaPublicKey, null);

        // Throws SignatureVerificationException
        algorithm.verify(decodedJWT);

        return true;
    }

    /**
     * Parses the defined public key to give it the RSAPublicKey format
     * required for the validation of the Algorithm object.
     *
     * @param publicPEMKey The public key as a text string coded in PEM format.
     * @return RSAPublicKey The public key in RSAPublicKey format.
     * @throws NoSuchAlgorithmException if the specified algorithm does not exist.
     * @throws InvalidKeySpecException if the key specification is invalid.
     */
    private RSAPublicKey publicKeyRSA(String publicPEMKey) throws NoSuchAlgorithmException, InvalidKeySpecException, IOException {
        String parsedPublicPEMKey = publicPEMKey
            .replace("-----BEGIN PUBLIC KEY-----", "")
            .replace("-----END PUBLIC KEY-----", "")
            .replaceAll("\\s", "");

        try (
            StringReader stringReader = new StringReader(parsedPublicPEMKey);
            // Throws IOException
            PemReader pemReader = new PemReader(stringReader)
        ) {
            byte[] decoded = Base64.getDecoder().decode(parsedPublicPEMKey);

            // Throws NoSuchAlgorithmException o InvalidKeySpecException
            return (RSAPublicKey) KeyFactory.getInstance("RSA").generatePublic(new X509EncodedKeySpec(decoded));
        }
    }
}
