/**
 * Rest layer visual models.
 */
package es.cecabank.app.web.rest.vm;
