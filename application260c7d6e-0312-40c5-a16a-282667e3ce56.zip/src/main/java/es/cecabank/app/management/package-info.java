/**
 * Application management.
 */
package es.cecabank.app.management;
